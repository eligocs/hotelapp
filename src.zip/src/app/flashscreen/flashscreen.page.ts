import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flashscreen',
  templateUrl: './flashscreen.page.html',
  styleUrls: ['./flashscreen.page.scss'],
})
export class FlashscreenPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
