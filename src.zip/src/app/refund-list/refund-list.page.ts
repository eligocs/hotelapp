import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-refund-list',
  templateUrl: './refund-list.page.html',
  styleUrls: ['./refund-list.page.scss'],
})
export class RefundListPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
