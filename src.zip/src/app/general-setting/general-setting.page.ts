import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-general-setting',
  templateUrl: './general-setting.page.html',
  styleUrls: ['./general-setting.page.scss'],
})
export class GeneralSettingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
